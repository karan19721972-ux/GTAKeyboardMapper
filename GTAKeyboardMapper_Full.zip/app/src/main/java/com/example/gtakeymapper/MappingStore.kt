package com.example.gtakeymapper

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object MappingStore {
    private const val PREF = "mapping_store"
    private const val KEY = "mappings"

    fun save(context: Context, mappings: List<Mapping>) {
        val arr = JSONArray()
        mappings.forEach {
            arr.put(JSONObject().apply {
                put("keyCode", it.keyCode)
                put("label", it.label)
                put("x", it.x.toDouble())
                put("y", it.y.toDouble())
            })
        }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    fun load(context: Context): MutableList<Mapping> {
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY, null) ?: return defaultMappings()
        return try {
            val arr = JSONArray(raw)
            MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Mapping(o.getInt("keyCode"), o.getString("label"),
                    o.getDouble("x").toFloat(), o.getDouble("y").toFloat())
            }
        } catch (_: Exception) {
            defaultMappings()
        }
    }

    fun defaultMappings(): MutableList<Mapping> = mutableListOf(
        Mapping(android.view.KeyEvent.KEYCODE_W, "W", 0.12f, 0.72f),
        Mapping(android.view.KeyEvent.KEYCODE_A, "A", 0.07f, 0.79f),
        Mapping(android.view.KeyEvent.KEYCODE_S, "S", 0.12f, 0.86f),
        Mapping(android.view.KeyEvent.KEYCODE_D, "D", 0.17f, 0.79f),
        Mapping(android.view.KeyEvent.KEYCODE_SPACE, "SPACE", 0.88f, 0.78f),
        Mapping(android.view.KeyEvent.KEYCODE_SHIFT_LEFT, "SHIFT", 0.80f, 0.68f),
        Mapping(android.view.KeyEvent.KEYCODE_F, "F", 0.74f, 0.60f),
        Mapping(android.view.KeyEvent.KEYCODE_R, "R", 0.88f, 0.60f),
        Mapping(android.view.KeyEvent.KEYCODE_E, "E", 0.80f, 0.60f),
        Mapping(android.view.KeyEvent.KEYCODE_ENTER, "ENTER", 0.92f, 0.10f)
    )
}
