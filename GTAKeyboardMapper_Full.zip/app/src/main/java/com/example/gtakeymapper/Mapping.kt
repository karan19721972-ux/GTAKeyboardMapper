package com.example.gtakeymapper

data class Mapping(
    val keyCode: Int,
    val label: String,
    var x: Float,
    var y: Float
)
