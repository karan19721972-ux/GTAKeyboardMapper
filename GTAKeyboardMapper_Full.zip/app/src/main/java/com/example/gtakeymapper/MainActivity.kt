package com.example.gtakeymapper

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout
    private lateinit var mappings: MutableList<Mapping>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mappings = MappingStore.load(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }

        val title = TextView(this).apply {
            text = "GTA Keyboard Mapper"
            textSize = 25f
            setTextColor(Color.BLACK)
        }
        root.addView(title)

        val info = TextView(this).apply {
            text = "Connect a USB/Bluetooth keyboard, enable Accessibility, then use the mappings below. Coordinates are normalized to the phone screen."
            textSize = 15f
            setPadding(0, 12, 0, 16)
        }
        root.addView(info)

        val access = Button(this).apply {
            text = "1. Enable Accessibility Service"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        root.addView(access)

        val overlay = Button(this).apply {
            text = "2. Allow Display Over Other Apps"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Overlay permission is already enabled.", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(overlay)

        val save = Button(this).apply {
            text = "Save mappings"
            setOnClickListener {
                MappingStore.save(this@MainActivity, mappings)
                Toast.makeText(this@MainActivity, "Mappings saved.", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(save)

        val reset = Button(this).apply {
            text = "Reset to GTA-style defaults"
            setOnClickListener {
                mappings = MappingStore.defaultMappings()
                renderRows()
            }
        }
        root.addView(reset)

        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        renderRows()
    }

    private fun renderRows() {
        list.removeAllViews()
        mappings.forEachIndexed { index, m ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 8, 0, 8)
            }

            val label = TextView(this).apply {
                text = "${m.label}:"
                textSize = 16f
            }
            row.addView(label, LinearLayout.LayoutParams(80, -2))

            val x = EditText(this).apply {
                hint = "X 0-1"
                setText("%.3f".format(m.x))
                inputType = 8194
            }
            val y = EditText(this).apply {
                hint = "Y 0-1"
                setText("%.3f".format(m.y))
                inputType = 8194
            }

            fun update() {
                m.x = x.text.toString().toFloatOrNull()?.coerceIn(0f, 1f) ?: m.x
                m.y = y.text.toString().toFloatOrNull()?.coerceIn(0f, 1f) ?: m.y
            }
            x.setOnFocusChangeListener { _, has -> if (!has) update() }
            y.setOnFocusChangeListener { _, has -> if (!has) update() }

            row.addView(x, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(y, LinearLayout.LayoutParams(0, -2, 1f))
            list.addView(row)
        }
    }
}
