package com.example.gtakeymapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class KeyboardAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val downPaths = HashMap<Int, Pair<Float, Float>>()
    private var mappings: List<Mapping> = emptyList()

    override fun onServiceConnected() {
        super.onServiceConnected()
        mappings = MappingStore.load(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (mappings.isEmpty()) mappings = MappingStore.load(this)
        val mapping = mappings.firstOrNull { it.keyCode == event.keyCode } ?: return false
        val dm = resources.displayMetrics
        val x = mapping.x * dm.widthPixels
        val y = mapping.y * dm.heightPixels

        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                if (event.repeatCount > 0 || downPaths.containsKey(event.keyCode)) return true
                downPaths[event.keyCode] = x to y
                dispatchTouch(x, y, 5000L)
                return true
            }
            KeyEvent.ACTION_UP -> {
                downPaths.remove(event.keyCode)
                dispatchRelease(x, y)
                return true
            }
        }
        return false
    }

    private fun dispatchTouch(x: Float, y: Float, holdMs: Long) {
        val p = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(p, 0, holdMs, true)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun dispatchRelease(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(p, 0, 1)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }
}
